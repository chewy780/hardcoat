import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = 'https://www.hardcoatsolutions.com';
  return [
    { url: `${base}/`, changeFrequency: 'monthly', priority: 1.0 },
    { url: `${base}/services`, changeFrequency: 'monthly', priority: 0.9 },
    { url: `${base}/projects`, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/buy-epoxy`, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/contact`, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/commercial-epoxy-sacramento`, changeFrequency: 'monthly', priority: 0.9 },
    { url: `${base}/commercial-epoxy-chico`, changeFrequency: 'monthly', priority: 0.9 }
  ];
}

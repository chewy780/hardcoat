import { NextRequest } from "next/server";

export async function POST(req: NextRequest){
  const body = await req.json().catch(()=>({}));
  const question = body?.question || "";
  const endpoint = process.env.AI_API_URL; // your external API endpoint (Cloudflare Worker / FastAPI etc.)
  if (!endpoint) {
    return new Response(JSON.stringify({ ok:false, error:"AI_API_URL not set", answer: "AI endpoint not configured." }), { status: 200 });
  }
  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type":"application/json", "Authorization": `Bearer ${process.env.AI_API_KEY||""}` },
    body: JSON.stringify({ question, source: "hardcoat-site" })
  }).catch((e)=>({ ok:false, json: async()=>({ error: e.message }) } as any));
  try{
    const j = await (res as any).json();
    return new Response(JSON.stringify({ ok:true, ...j }), { status: 200 });
  }catch{
    return new Response(JSON.stringify({ ok:false, error:"Bad AI response" }), { status: 200 });
  }
}

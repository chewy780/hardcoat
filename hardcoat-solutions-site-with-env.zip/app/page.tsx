import JSONLD from "@/components/JSONLD";

export default function Home() {
  const business = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "HardCoat Solutions",
    "telephone": "+1-530-570-7787",
    "url": "https://www.hardcoatsolutions.com",
    "areaServed": ["Sacramento","Chico","Northern California"],
    "image": "https://www.hardcoatsolutions.com/hero.jpg"
  };

  return (
    <div className="space-y-10">
      <section className="glass p-8 mt-4">
        <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight">
          Commercial Epoxy Flooring in <span className="text-brand">Sacramento</span> & <span className="text-brand">Chico</span>
        </h1>
        <p className="mt-4 text-lg opacity-90">Urethane cement & epoxy systems for warehouses, food processing, healthcare, and retail. Night & weekend installs. Licensed & Insured.</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <a href="/contact" className="px-4 py-2 rounded-lg bg-brand text-black font-semibold">Get a Free Quote</a>
          <a href="/projects" className="px-4 py-2 rounded-lg border border-white/20">See Projects</a>
        </div>
      </section>

      <section className="grid md:grid-cols-4 gap-4">
        {["Commercial","Industrial","Food & Beverage","Garage"].map((label,i)=>(
          <div key={i} className="glass p-5">
            <h3 className="font-semibold">{label}</h3>
            <p className="opacity-80 text-sm mt-2">Durable, chemical-resistant, easy to clean surfaces built for heavy use.</p>
            <a className="mt-3 inline-block text-brand" href="/services">Learn more →</a>
          </div>
        ))}
      </section>

      <section className="glass p-6">
        <h2 className="text-xl font-semibold">Service Areas</h2>
        <p className="opacity-85 mt-2">We specialize in Northern California with a focus on Sacramento and Chico.</p>
        <div className="mt-3 flex gap-3">
          <a href="/commercial-epoxy-sacramento" className="underline">Commercial Epoxy — Sacramento</a>
          <a href="/commercial-epoxy-chico" className="underline">Commercial Epoxy — Chico</a>
        </div>
      </section>

      <section className="glass p-6">
        <h2 className="text-xl font-semibold">Buy Epoxy Products</h2>
        <p className="opacity-85">DIY or facility maintenance? Purchase kits and materials directly.</p>
        <a href="/buy-epoxy" className="mt-3 inline-block px-4 py-2 rounded-lg bg-white text-black">Shop Now</a>
      </section>

      <JSONLD data={business} />
          <ChatWidget />
    </div>
  );
}

// Floating chat
import ChatWidget from '@/components/ChatWidget';
export const dynamic = 'force-static';

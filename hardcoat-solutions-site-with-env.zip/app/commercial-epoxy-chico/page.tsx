export const metadata = { title: "Commercial Epoxy Flooring in Chico | HardCoat Solutions" };

export default function Page(){
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Commercial Epoxy Flooring — Chico</h1>
      <p className="opacity-85">We install epoxy & urethane cement systems for Chico warehouses, food & beverage, healthcare, and retail environments. Rapid installs, night/weekend work, and long-wear surfaces.</p>
      <ul className="list-disc pl-6 opacity-85">
        <li>Expert prep: shot-blasting, diamond grinding, crack repair</li>
        <li>Non-slip, chemical & thermal shock resistant systems</li>
        <li>Maintenance plans & warranties</li>
      </ul>
      <a className="inline-block mt-4 px-4 py-2 rounded-lg bg-brand text-black" href="/contact">Get a Free Quote</a>
    </div>
  );
}

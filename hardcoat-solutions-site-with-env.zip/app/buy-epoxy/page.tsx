export const metadata = { title: "Buy Epoxy Products | HardCoat Solutions" };

export default function Buy(){
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Buy Epoxy Products</h1>
      <p className="opacity-85">Order epoxy kits and materials from our partner store. For product help, call (530) 570‑7787.</p>
      <div className="glass p-2">
        <iframe
          src="https://www.hardcoatsolutions.xyz"
          className="w-full"
          style={{minHeight: "1200px", border: "0"}}
          loading="lazy"
        />
      </div>
    </div>
  );
}

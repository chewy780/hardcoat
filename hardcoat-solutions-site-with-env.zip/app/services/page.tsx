export const metadata = { title: "Commercial & Industrial Epoxy | Urethane Cement | Sacramento & Chico" };

const services = [
  { title: "Commercial Epoxy", desc: "Retail, offices, showrooms. Attractive + durable."},
  { title: "Industrial Epoxy", desc: "Warehouses, manufacturing. High-build, abrasion & impact resistant."},
  { title: "Urethane Cement", desc: "Food & beverage, thermal shock resistant, antimicrobial options."},
  { title: "ESD & Specialty", desc: "Electrostatic dissipative, chemical containment, non-slip."}
];

export default function Services(){
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Services</h1>
      <div className="grid md:grid-cols-2 gap-4">
        {services.map((s,i)=>(
          <div key={i} className="glass p-6">
            <h3 className="font-semibold">{s.title}</h3>
            <p className="opacity-85 mt-2">{s.desc}</p>
          </div>
        ))}
      </div>
      <a className="inline-block mt-4 px-4 py-2 rounded-lg bg-brand text-black" href="/contact">Request a Quote</a>
    </div>
  )
}

# HardCoat Solutions — SEO-Optimized Website (Next.js)

Marketing site optimized for **Commercial Epoxy Flooring** in **Sacramento & Chico**.

## Features
- Next.js App Router + Tailwind (dark glass/neon theme)
- Landing pages:
  - `/` Home
  - `/services`
  - `/projects`
  - `/buy-epoxy` (embeds https://www.hardcoatsolutions.xyz)
  - `/contact` (quote form -> webhook)
  - `/commercial-epoxy-sacramento`
  - `/commercial-epoxy-chico`
- SEO:
  - Proper titles & metadata
  - `robots.txt` & `sitemap.xml`
  - LocalBusiness & Service JSON-LD
  - Clean URLs & alt-text placeholders
- Lead capture:
  - Quote form posts to `NEXT_PUBLIC_ZAPIER_WEBHOOK_URL` if set
- AI:
  - Floating chat widget calls `/api/ai` which proxies to `AI_API_URL` (set via env)

## Dev
```bash
npm i
npm run dev
# visit http://localhost:3000
```

## Build
```bash
npm run build && npm start
```

## Environment
Create `.env.local` (local dev):
```
NEXT_PUBLIC_ZAPIER_WEBHOOK_URL=
AI_API_URL=
AI_API_KEY=
```

## Deploy / Wix
- Option 1: Deploy this app to Vercel/Netlify and **embed** into your Wix pages via iframe.
- Option 2: Move copy/images into Wix pages and keep this repo as your **content source** (copy meta tags and JSON-LD into Wix's custom code).

## License
All rights reserved to HardCoat Solutions.

import "./globals.css";
import { ReactNode } from "react";

export const metadata = {
  title: "HardCoat Solutions | Commercial Epoxy Flooring - Sacramento & Chico",
  description: "Commercial epoxy & urethane cement flooring. Warehouses, food & beverage, healthcare, retail. Sacramento & Chico.",
  metadataBase: new URL("https://www.hardcoatsolutions.com")
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-black text-white">
        <div className="fixed inset-0 -z-10 bg-animated"></div>
        <header className="w-full sticky top-0 z-50 backdrop-blur-xl bg-black/40 border-b border-white/10">
          <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
            <a href="/" className="font-semibold tracking-tight text-lg">HardCoat Solutions</a>
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <a href="/services" className="opacity-90 hover:opacity-100">Services</a>
              <a href="/projects" className="opacity-90 hover:opacity-100">Projects</a>
              <a href="/buy-epoxy" className="opacity-90 hover:opacity-100">Buy Epoxy</a>
              <a href="/contact" className="opacity-90 hover:opacity-100">Contact</a>
            </nav>
            <a href="tel:+15305707787" className="px-3 py-1.5 rounded-lg bg-white text-black text-sm font-semibold">Call (530) 570‑7787</a>
          </div>
        </header>
        <main className="max-w-6xl mx-auto px-4 py-10">{children}</main>
        <footer className="border-t border-white/10 mt-16">
          <div className="max-w-6xl mx-auto px-4 py-6 text-sm opacity-80">
            © {new Date().getFullYear()} HardCoat Solutions • Sacramento & Chico • Licensed & Insured
          </div>
        </footer>
      </body>
    </html>
  );
}

'use client';
import { useState } from 'react';

export const metadata = { title: "Get a Free Quote | Contact" };

export default function Contact(){
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  async function onSubmit(e: React.FormEvent<HTMLFormElement>){
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setLoading(true);
    const webhook = process.env.NEXT_PUBLIC_ZAPIER_WEBHOOK_URL || "";
    if (webhook) {
      await fetch(webhook, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(Object.fromEntries(form))
      }).catch(()=>{});
    }
    setLoading(false);
    setSent(true);
    (e.currentTarget as HTMLFormElement).reset();
  }
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="glass p-6">
        <h1 className="text-3xl font-bold">Get a Free Quote</h1>
        <p className="opacity-85 mt-2">Tell us about your project. We typically reply within one business day.</p>
        <form onSubmit={onSubmit} className="mt-4 space-y-3">
          <input name="name" required placeholder="Name" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10 neon-ring"/>
          <input name="phone" required placeholder="Phone" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10 neon-ring"/>
          <input name="email" placeholder="Email" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10 neon-ring"/>
          <input name="sqft" placeholder="Approx. square feet" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10 neon-ring"/>
          <textarea name="message" placeholder="Project details" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10 neon-ring min-h-[120px]" />
          <button disabled={loading} className="px-4 py-2 rounded-lg bg-brand text-black font-semibold">{loading ? "Sending…" : "Send"}</button>
          {sent && <div className="text-green-400">Thanks! We’ll be in touch shortly.</div>}
        </form>
      </div>
      <div className="glass p-6">
        <h2 className="text-xl font-semibold">Service Area</h2>
        <p className="opacity-85">Sacramento • Chico • Northern California</p>
        <div className="mt-4 text-sm opacity-80">
          <p><strong>Phone:</strong> <a href="tel:+15305707787" className="underline">(530) 570‑7787</a></p>
          <p><strong>Email:</strong> troy@hardcoatsolutions.com</p>
        </div>
      </div>
    </div>
  );
}

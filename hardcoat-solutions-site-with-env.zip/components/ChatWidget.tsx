'use client';
import { useState } from 'react';

export default function ChatWidget(){
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [a, setA] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  async function ask(){
    setBusy(true);
    const res = await fetch('/api/ai', { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ question: q }) });
    const j = await res.json();
    setA(j.answer || j.error || 'Thanks!');
    setBusy(false);
  }
  return (
    <div className="fixed bottom-4 right-4">
      {!open && <button onClick={()=>setOpen(true)} className="px-4 py-2 rounded-full bg-brand text-black font-semibold shadow-lg">Chat</button>}
      {open && (
        <div className="glass p-4 w-[320px]">
          <div className="flex justify-between items-center">
            <div className="font-semibold">Ask about epoxy</div>
            <button onClick={()=>setOpen(false)} className="opacity-70 hover:opacity-100">✕</button>
          </div>
          <textarea className="mt-2 w-full min-h-[80px] rounded-lg bg-white/10 border border-white/10 p-2"
            placeholder="Ask about pricing, systems, or scheduling…" value={q} onChange={e=>setQ(e.target.value)} />
          <button onClick={ask} disabled={busy} className="mt-2 px-3 py-1.5 rounded-lg bg-white text-black">{busy?'Thinking…':'Ask'}</button>
          {a && <div className="mt-2 text-sm opacity-90">{a}</div>}
        </div>
      )}
    </div>
  );
}

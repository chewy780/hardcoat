/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#00E0FF',
          dark: '#00B7D6',
          violet: '#9b5cff'
        }
      },
      boxShadow: {
        glass: "0 0 40px rgba(0, 224, 255, .08)"
      },
      backdropBlur: { xl: '16px' },
      borderRadius: { '2xl': '1rem' },
      keyframes: {
        'bg-shift': { '0%': { backgroundPosition: '0% 50%'}, '100%': { backgroundPosition: '100% 50%'} },
        'blink': { '0%,100%': {opacity:1}, '50%': {opacity:.3} }
      },
      animation: {
        'bg-shift': 'bg-shift 20s ease infinite alternate',
        'blink': 'blink 1.4s steps(2, start) infinite'
      }
    }
  },
  plugins: []
};

'use client';
import React from 'react';

export default function JSONLD({ data }: { data: Record<string, any>}){
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}

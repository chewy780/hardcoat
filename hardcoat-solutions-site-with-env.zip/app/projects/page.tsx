export const metadata = { title: "Epoxy Projects | Case Studies" };

const projects = [
  { name: "Warehouse – Sacramento", size: "18,000 sq ft", system: "High-build epoxy + urethane topcoat", result: "Improved light reflectivity & safety" },
  { name: "Food Processing – Chico", size: "6,200 sq ft", system: "Urethane cement + cove", result: "Thermal shock & antimicrobial" }
];

export default function Projects(){
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Projects</h1>
      <div className="grid md:grid-cols-2 gap-4">
        {projects.map((p,i)=>(
          <div key={i} className="glass p-6">
            <h3 className="font-semibold">{p.name}</h3>
            <ul className="opacity-85 text-sm mt-2 space-y-1">
              <li><strong>Size:</strong> {p.size}</li>
              <li><strong>System:</strong> {p.system}</li>
              <li><strong>Outcome:</strong> {p.result}</li>
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
